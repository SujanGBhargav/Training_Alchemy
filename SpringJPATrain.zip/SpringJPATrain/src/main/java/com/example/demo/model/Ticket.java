package com.example.demo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ticket")
public class Ticket {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int ticket_id;
	
	@Column(name="pnr")
	private String pnr;
	
	@Column(name="Travel_date")
	private Date travel_date;
	
	@Column(name="train_name")
	private String train_name;
	
	@Column(name="no_of_pass")
	private int no_of_pass;
	
	@Column(name="total_fare")
	private double total_fare;

	public Ticket()
	{
		
	}

	public Ticket(String pnr, String train_name, Date travel_date, int no_of_pass, double total_fare) {
		super();
		this.pnr = pnr;
		this.travel_date = travel_date;
		this.train_name=train_name;
		this.no_of_pass = no_of_pass;
		this.total_fare = total_fare;
	}

	public int getTicket_id() {
		return ticket_id;
	}

	public void setTicket_id(int ticket_id) {
		this.ticket_id = ticket_id;
	}

	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public Date getTravel_date() {
		return travel_date;
	}

	public void setTravel_date(Date travel_date) {
		this.travel_date = travel_date;
	}

	public String getTrain_name() {
		return train_name;
	}

	public void setTrain_name(String train_name) {
		this.train_name = train_name;
	}

	public int getNo_of_pass() {
		return no_of_pass;
	}

	public void setNo_of_pass(int no_of_pass) {
		this.no_of_pass = no_of_pass;
	}

	public double getTotal_fare() {
		return total_fare;
	}

	public void setTotal_fare(double total_fare) {
		this.total_fare = total_fare;
	}

	@Override
	public String toString() {
		return "Ticket [ticket_id=" + ticket_id + ", pnr=" + pnr + ", travel_date=" + travel_date + ", train_name="
				+ train_name + ", no_of_pass=" + no_of_pass + ", total_fare=" + total_fare + "]";
	}

}